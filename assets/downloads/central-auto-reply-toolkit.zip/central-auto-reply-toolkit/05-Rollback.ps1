<#
  05 - Roll back a go-live from its backup folder
  .\05-Rollback.ps1 -BackupPath 'C:\Temp\CentralAutoReply\GoLive-Backup-20261001-0811' -WhatIf
  Restores: rule SentTo list, scope group membership, OOF state/audience/messages, and
  re-enables the inbox rules that were disabled. Fastest stop instead: turn the flow OFF.
#>
[CmdletBinding(SupportsShouldProcess)]
param([Parameter(Mandatory)][string]$BackupPath)
. "$PSScriptRoot\00-Config.ps1"

# Rule
$old = Import-Clixml (Join-Path $BackupPath 'TransportRule.xml')
if ($PSCmdlet.ShouldProcess($RuleName, 'Restore SentTo')) { Set-TransportRule -Identity $RuleName -SentTo $old.SentTo; "Rule SentTo restored ($($old.SentTo.Count))" }

# Group - remove members added at go-live
$was = (Import-Csv (Join-Path $BackupPath 'ScopeGroupMembers.csv')).PrimarySmtpAddress
Get-DistributionGroupMember -Identity $ScopeGroup -ResultSize Unlimited | Where-Object { $was -notcontains $_.PrimarySmtpAddress } | ForEach-Object {
    if ($PSCmdlet.ShouldProcess($_.PrimarySmtpAddress, 'Remove from scope group')) {
        Remove-DistributionGroupMember -Identity $ScopeGroup -Member $_.PrimarySmtpAddress -BypassSecurityGroupManagerCheck -Confirm:$false; "Removed $($_.PrimarySmtpAddress)"
    }
}

# Inbox rules
$rf = Join-Path $BackupPath 'Teardown-Rules.txt'
if (Test-Path $rf) { Get-Content $rf | Where-Object { $_.Trim() -and -not $_.Trim().StartsWith('#') } | ForEach-Object {
    if ($PSCmdlet.ShouldProcess($_, 'Enable inbox rule')) { Enable-InboxRule -Identity $_ -Confirm:$false; "Enabled rule $_" } } }

# Out-of-office
Get-ChildItem $BackupPath -Filter '*-OOF.xml' | ForEach-Object {
    $o = Import-Clixml $_.FullName
    if ($PSCmdlet.ShouldProcess($o.Identity, 'Restore OOF')) {
        $p = @{ Identity=$o.MailboxOwnerId; AutoReplyState=$o.AutoReplyState; ExternalAudience=$o.ExternalAudience
                InternalMessage=$o.InternalMessage; ExternalMessage=$o.ExternalMessage }
        if ($o.AutoReplyState -eq 'Scheduled') { $p.StartTime=$o.StartTime; $p.EndTime=$o.EndTime }
        Set-MailboxAutoReplyConfiguration @p; "OOF restored: $($o.MailboxOwnerId)"
    }
}
