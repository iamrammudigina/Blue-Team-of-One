<#
  03 - Create the Exchange side of the central auto-reply (run ONCE per deployment)
  Creates: hidden intake mailbox, hidden scope group, flow-account permissions,
           mail flow rule that BCCs external mail for in-scope boxes to the intake.
  Start with 1-2 pilot mailboxes in Scope.csv; widen at go-live with 04-GoLive.ps1.
  Not here (do in Entra): Graph app with MailboxSettings.Read, GroupMember.Read.All,
  User.ReadBasic.All (application, admin-consented). Keep the secret out of every file.
#>
. "$PSScriptRoot\00-Config.ps1"
$Scope = Get-ScopeAddresses

# 1. Intake mailbox - flow watches it; hidden from the GAL
New-Mailbox -Shared -Name "$Prefix-intake" -DisplayName "$Prefix intake" -PrimarySmtpAddress $IntakeMailbox
Set-Mailbox $IntakeMailbox -HiddenFromAddressListsEnabled $true
Add-MailboxPermission $IntakeMailbox -User $FlowAccount -AccessRights FullAccess -AutoMapping $false

# 2. Scope group - the flow reads its members through Graph to decide whose OOF to check
New-DistributionGroup -Name "$Prefix-scope" -Type Security -PrimarySmtpAddress $ScopeGroup -Members $Scope
Set-DistributionGroup $ScopeGroup -HiddenFromAddressListsEnabled $true -RequireSenderAuthenticationEnabled $true
Write-Host "Group object ID for the flow:" -ForegroundColor Cyan
Get-DistributionGroup $ScopeGroup | Select-Object DisplayName, ExternalDirectoryObjectId

# 3. Reply-from mailbox - the flow needs BOTH Full Access and Send As
#    (Send As alone gives 404 ErrorItemNotFound on "Send an email from a shared mailbox (V2)").
#    Allow up to ~60 min for permissions to apply.
Add-MailboxPermission   $ReplyFrom -User $FlowAccount -AccessRights FullAccess -AutoMapping $false
Add-RecipientPermission $ReplyFrom -Trustee $FlowAccount -AccessRights SendAs -Confirm:$false

# 4. Mail flow rule - DIRECT SentTo list (not SentToMemberOf: group changes are cached for hours)
#    Loop guards: OOF messages, Auto-Submitted auto-*, Precedence bulk/list/junk, spam (SCL > 4).
New-TransportRule -Name $RuleName -Comments $RuleComment `
    -FromScope NotInOrganization `
    -SentTo $Scope `
    -BlindCopyTo $IntakeMailbox `
    -ExceptIfMessageTypeMatches OOF `
    -ExceptIfHeaderMatchesMessageHeader 'Auto-Submitted' -ExceptIfHeaderMatchesPatterns '^auto-' `
    -ExceptIfHeaderContainsMessageHeader 'Precedence' -ExceptIfHeaderContainsWords 'bulk','list','junk' `
    -ExceptIfSCLOver 4 -Mode Enforce

# 5. Rule ORDER check. Any rule above ours with StopRuleProcessing = True (e.g. a mail
#    gateway such as Egress / Mimecast that routes mail out and back) must stay ABOVE ours.
#    Ours must sit below it so it fires on the return pass. Never move ours above a gateway rule.
Get-TransportRule | Sort-Object Priority | Format-Table Priority, Name, State, StopRuleProcessing -AutoSize

# 6. Verify
Get-Mailbox $IntakeMailbox | Select-Object DisplayName, RecipientTypeDetails, HiddenFromAddressListsEnabled
Get-DistributionGroupMember $ScopeGroup | Select-Object DisplayName, PrimarySmtpAddress
Get-MailboxPermission $ReplyFrom   | Where-Object User -like "*$FlowAccount*"
Get-RecipientPermission $ReplyFrom | Where-Object Trustee -like "*$FlowAccount*"
Get-TransportRule $RuleName | Format-List Name, State, Priority, FromScope, SentTo, BlindCopyTo, Except*
Write-Host "New mail flow rules can take up to ~30 min to apply." -ForegroundColor Yellow

# Remove everything (test / abandon only):
# Remove-TransportRule $RuleName -Confirm:$false
# Remove-DistributionGroup $ScopeGroup -Confirm:$false
# Remove-Mailbox $IntakeMailbox -Confirm:$false
