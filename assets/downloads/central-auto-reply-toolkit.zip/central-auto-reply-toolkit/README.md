# Central Auto-Reply – PowerShell toolkit

Reusable Exchange Online scripts for the **Central Auto-Reply for Team Mailboxes** automation
(first built for a shared team-mailbox deployment, 2026). They cover everything on the Exchange side:
finding the mailboxes, checking for existing auto-replies, building the plumbing, going live,
rolling back and troubleshooting. The Power Automate flow and the Entra (Graph) app are
set up separately – see the library entry and Technical Build Guide.

**No secrets, tenant IDs or real user data in these files.** Keep it that way.

## Before you start
- Exchange Online PowerShell module: `Connect-ExchangeOnline`
- Downloaded scripts are blocked by Windows: `Get-ChildItem *.ps1 | Unblock-File`
  (or `Set-ExecutionPolicy -Scope Process Bypass` for the current window only)
- Fill in `00-Config.ps1` once per client.

## Files
| File | What it does | Changes anything? |
|---|---|---|
| 00-Config.ps1 | Shared settings (domain, object names, paths). Dot-sourced by all scripts | No |
| 01-Resolve-Mailboxes.ps1 | Names.txt → Scope.csv using fuzzy name match (ANR) | No |
| 02-Scan-ExistingReplies.ps1 | OOF + reply/forward/Outlook-only rules for every in-scope box, with backups | No |
| 03-Setup-Prerequisites.ps1 | Intake mailbox, scope group, flow permissions, mail flow rule | **Yes** (one-time) |
| 04-GoLive.ps1 | Backup → disable old replies → add to group → add to rule → verify. Supports `-WhatIf` | **Yes** |
| 05-Rollback.ps1 | Restores rule, group, inbox rules and OOF from a go-live backup. Supports `-WhatIf` | **Yes** |
| 06-Troubleshoot.ps1 | Message trace, rules hit, rule order, in-scope check, OOF view, permissions | No |
| Scope.csv / Names.txt / Teardown-*.* | Input samples – replace with real data | – |

## Order of use
1. `01` – resolve the client's list → confirm Scope.csv with the client.
2. `02` – scan. Review with the client: what to switch off at go-live.
   Also check Power Automate (admin center → Environments → Default → Resources → Flows).
3. `03` – with 1–2 pilot mailboxes in Scope.csv. Build/import the flow, pilot, test.
4. Put the final list in Scope.csv; fill Teardown-Rules.txt and Teardown-OOF.csv from the scan.
5. `04 -WhatIf`, then `04`. Smoke test from an external address.
6. Monitor 1–2 days; close the change. `05` only if you need to undo.

## Lessons learned (why the scripts look like this)
- **Direct SentTo list in the rule, not SentToMemberOf** – transport caches group
  membership for hours; new members were not matched.
- **The group is still needed** – the flow reads it via Graph (instant) to decide whose OOF to check.
- **Reply-from mailbox needs Full Access AND Send As** for the flow account; Send As alone
  returns 404 ErrorItemNotFound. Permissions take up to ~60 min.
- **Mail gateways (Egress, Mimecast) route mail out and back.** Their rule (Stop processing)
  must stay above ours; ours fires on the return pass.
- **Message trace detail only lists rules that matched** – you can't see why one didn't. Change one thing at a time.
- **Outlook-only "reply with template" rules** show `SupportedByTask = False` and still double-reply
  whenever the user's Outlook is open – disable them at go-live.
- **ExternalAudience Known (contacts only)** – the flow treats the box as away but non-contacts get
  no OOF either → no reply at all. Set those to None (or All).
- **Use ExternalAudience None instead of turning OOF off for people** – colleagues still see it;
  external senders get the central reply.
- **Test subjects**: avoid "auto reply", "out of office", "automatic reply" – the loop filter skips them.
- **OOF replies once per sender per period** – reset OOF between OOF tests from the same sender.
- Name-based lookups can return a "shared" mailbox that is actually a UserMailbox – record the real type.
