<#
  Central Auto-Reply toolkit - shared settings. Every script dot-sources this file.
  Fill in once per deployment. NEVER put secrets, client secrets or passwords here.
#>

# Tenant / naming
$Domain        = 'contoso.org'                                  # client's primary mail domain
$Prefix        = 'teamautoreply'                                # short name used for all objects

# Objects the solution uses
$FlowAccount   = "svc-automation@$Domain"                       # account that owns the flow + connections
$IntakeMailbox = "$Prefix-intake@$Domain"                       # hidden shared mailbox the flow watches
$ScopeGroup    = "$Prefix-scope@$Domain"                        # mail-enabled security group read by the flow (Graph)
$ReplyFrom     = "team@$Domain"                                 # central address replies are sent from
$RuleName      = "$Prefix - BCC external mail to intake"        # Exchange mail flow rule
$RuleComment   = 'INC0000000 / CHG0000000'                      # ticket / change reference

# In-scope mailboxes: one address per line in Scope.csv (column: Address).
# Build it with 01-Resolve-Mailboxes.ps1 or by hand.
$ScopeCsv      = Join-Path $PSScriptRoot 'Scope.csv'

# Where reports and backups go
$WorkRoot      = 'C:\Temp\CentralAutoReply'

function Get-ScopeAddresses {
    if (-not (Test-Path $ScopeCsv)) { throw "Scope.csv not found at $ScopeCsv" }
    @(Import-Csv $ScopeCsv | ForEach-Object { $_.Address.Trim() } | Where-Object { $_ })
}

function New-WorkFolder ([string]$Name) {
    $p = Join-Path $WorkRoot "$Name-$(Get-Date -Format yyyyMMdd-HHmm)"
    New-Item -ItemType Directory -Path $p -Force | Out-Null
    $p
}
