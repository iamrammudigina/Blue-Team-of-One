<#
  01 - Resolve display names to mailbox addresses (READ-ONLY)
  Input : Names.txt  - one name or alias per line (as the client gave them)
  Output: Scope.csv  - Address column, ready for the other scripts
          Resolve-Report.csv - every match, so you can check MULTIPLE / NOT FOUND
  Uses ANR (ambiguous name resolution), so spelling variants and aliases still match.
#>
. "$PSScriptRoot\00-Config.ps1"

$names = Get-Content (Join-Path $PSScriptRoot 'Names.txt') | Where-Object { $_.Trim() }
$report = foreach ($n in $names) {
    $hits = @(Get-EXOMailbox -Anr $n.Trim() -Properties UserPrincipalName,RecipientTypeDetails -ErrorAction SilentlyContinue)
    if ($hits.Count -eq 0) {
        [pscustomobject]@{ Name=$n; Match='NOT FOUND'; DisplayName=''; UPN=''; PrimarySmtp=''; Type='' }
    } else {
        foreach ($h in $hits) {
            [pscustomobject]@{
                Name=$n; Match= if ($hits.Count -gt 1) {'MULTIPLE'} else {'OK'}
                DisplayName=$h.DisplayName; UPN=$h.UserPrincipalName
                PrimarySmtp=$h.PrimarySmtpAddress; Type=$h.RecipientTypeDetails
            }
        }
    }
}

$report | Format-Table -AutoSize
$report | Export-Csv (Join-Path $PSScriptRoot 'Resolve-Report.csv') -NoTypeInformation
$report | Where-Object Match -eq 'OK' | Select-Object @{n='Address';e={$_.PrimarySmtp}} |
    Export-Csv $ScopeCsv -NoTypeInformation

Write-Host "`nScope.csv written with the OK matches." -ForegroundColor Green
Write-Host "Add the right address for any MULTIPLE / NOT FOUND rows by hand, then confirm the list with the client." -ForegroundColor Yellow
Write-Host "Note: RecipientTypeDetails tells you if a 'shared' box is really a UserMailbox - record it." -ForegroundColor Yellow
