<#
  02 - Scan in-scope mailboxes for existing auto-replies (READ-ONLY, changes nothing)
  For every address in Scope.csv:
    - out-of-office state, audience, schedule, external message (first 150 chars)
    - inbox rules that reply / forward / redirect, plus Outlook-only rules (SupportedByTask = False)
    - full backup (Export-Clixml) of OOF + all inbox rules for rollback
  Output folder: 01-Summary.csv, 02-Reply-Forward-Rules.csv, per-mailbox XML backups.
  Not covered (check by hand): Power Automate flows - Power Platform admin center >
  Environments > Default > Resources > Flows; search names for reply / auto / the mailbox.
#>
. "$PSScriptRoot\00-Config.ps1"
$Out = New-WorkFolder 'Scan'
$Summary = @(); $RuleRows = @()

foreach ($s in Get-ScopeAddresses) {
    $m = Get-EXOMailbox -Identity $s -ErrorAction SilentlyContinue
    if (-not $m) { $Summary += [pscustomobject]@{ Address=$s; Resolved='NOT FOUND' }; continue }
    $addr  = $m.PrimarySmtpAddress
    $oof   = Get-MailboxAutoReplyConfiguration -Identity $addr
    $rules = @(Get-InboxRule -Mailbox $addr -ErrorAction SilentlyContinue)

    $oof   | Export-Clixml (Join-Path $Out "$($m.Alias)-OOF.xml")
    $rules | Export-Clixml (Join-Path $Out "$($m.Alias)-InboxRules.xml")

    $flagged = $rules | Where-Object {
        $_.ForwardTo -or $_.ForwardAsAttachmentTo -or $_.RedirectTo -or $_.SendTextMessageNotificationTo -or
        $_.Description -match 'reply|respond|template|forward|redirect' -or $_.SupportedByTask -eq $false
    }
    foreach ($r in $flagged) {
        $RuleRows += [pscustomobject]@{
            Mailbox=$addr; RuleName=$r.Name; Enabled=$r.Enabled; Priority=$r.Priority
            OutlookOnly=($r.SupportedByTask -eq $false)
            ForwardTo=($r.ForwardTo -join '; '); RedirectTo=($r.RedirectTo -join '; ')
            Description=($r.Description -replace '\s+',' ').Trim(); RuleIdentity=$r.Identity
        }
    }

    $msg = (($oof.ExternalMessage -replace '<[^>]+>',' ') -replace '\s+',' ').Trim()
    $Summary += [pscustomobject]@{
        Address=$addr; Resolved='OK'; Type=$m.RecipientTypeDetails
        OOFState=$oof.AutoReplyState; ExternalAudience=$oof.ExternalAudience
        Start= if ($oof.AutoReplyState -eq 'Scheduled') {$oof.StartTime} else {''}
        End=   if ($oof.AutoReplyState -eq 'Scheduled') {$oof.EndTime}   else {''}
        ExternalMsg= if ($msg.Length -gt 150) { $msg.Substring(0,150)+'...' } else { $msg }
        TotalRules=$rules.Count; FlaggedRules=@($flagged).Count
        EnabledFlaggedRules=@($flagged | Where-Object Enabled).Count
    }
}

$Summary  | Export-Csv (Join-Path $Out '01-Summary.csv') -NoTypeInformation
$RuleRows | Export-Csv (Join-Path $Out '02-Reply-Forward-Rules.csv') -NoTypeInformation
$Summary | Format-Table Address,Type,OOFState,ExternalAudience,FlaggedRules,EnabledFlaggedRules -AutoSize

Write-Host "`nSaved to $Out" -ForegroundColor Green
Write-Host @"
How to read it:
 - OOF Enabled/Scheduled with ExternalAudience All   -> flow treats the box as away; decide: keep, off, or external-off.
 - OOF with ExternalAudience Known (contacts only)    -> flow treats it as away but non-contacts get NO reply. Set to None or All.
 - Enabled flagged rule that replies (often OutlookOnly) -> would double-reply. Add its RuleIdentity to Teardown-Rules.txt.
 - Flagged rules that only move/delete/categorise    -> leave alone.
"@ -ForegroundColor Yellow
