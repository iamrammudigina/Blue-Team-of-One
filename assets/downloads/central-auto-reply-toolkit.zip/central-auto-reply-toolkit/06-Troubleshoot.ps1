<#
  06 - Troubleshooting helpers (READ-ONLY). Dot-source, then call the function you need:
     . .\06-Troubleshoot.ps1
     Trace-AutoReply -Subject 'IT check' -Minutes 30
#>
. "$PSScriptRoot\00-Config.ps1"

# Did the rule copy the email to intake, and did a reply go out?
function Trace-AutoReply ([string]$Subject, [int]$Minutes = 60) {
    Get-MessageTraceV2 -StartDate (Get-Date).AddMinutes(-$Minutes) -EndDate (Get-Date) |
        Where-Object Subject -like "*$Subject*" | Sort-Object Received |
        Format-Table @{n='Local';e={$_.Received.ToLocalTime()}}, SenderAddress, RecipientAddress, Subject, Status -AutoSize
}

# Which rules acted on one message? (detail lists ONLY rules that matched - absence = did not match)
function Get-RulesHit ([string]$Recipient, [string]$Subject, [int]$Hours = 2) {
    Get-MessageTraceV2 -RecipientAddress $Recipient -StartDate (Get-Date).AddHours(-$Hours) -EndDate (Get-Date) |
        Where-Object Subject -like "*$Subject*" | ForEach-Object {
            "----- $($_.Received.ToLocalTime())  $($_.Subject)"
            $_ | Get-MessageTraceDetailV2 | Where-Object Event -match 'Transport rule' | Format-Table Date, Event, Detail -Wrap
        }
}

# Rule order - gateway rules with StopRuleProcessing must sit ABOVE ours
function Show-RuleOrder { Get-TransportRule | Sort-Object Priority | Format-Table Priority, Name, State, StopRuleProcessing -AutoSize }

# Is an address actually in scope?
function Test-InScope ([string]$Address) {
    [pscustomobject]@{
        Address = $Address
        InRule  = ((Get-TransportRule $RuleName).SentTo -contains $Address)
        InGroup = ((Get-DistributionGroupMember $ScopeGroup -ResultSize Unlimited).PrimarySmtpAddress -contains $Address)
    }
}

# What will the flow see for this mailbox's out-of-office?
function Get-OofView ([string]$Address) {
    Get-MailboxAutoReplyConfiguration $Address | Select-Object Identity, AutoReplyState, ExternalAudience, StartTime, EndTime
}

# Flow account permissions (404 on send = Full Access missing on reply-from)
function Test-FlowPermissions {
    Get-MailboxPermission   $IntakeMailbox | Where-Object User -like "*$FlowAccount*" | Select-Object Identity, User, AccessRights
    Get-MailboxPermission   $ReplyFrom     | Where-Object User -like "*$FlowAccount*" | Select-Object Identity, User, AccessRights
    Get-RecipientPermission $ReplyFrom     | Where-Object Trustee -like "*$FlowAccount*" | Select-Object Identity, Trustee, AccessRights
}

Write-Host 'Loaded: Trace-AutoReply, Get-RulesHit, Show-RuleOrder, Test-InScope, Get-OofView, Test-FlowPermissions' -ForegroundColor Green
