<#
  04 - Go-live: back up, switch off old replies, add mailboxes to the group and the rule, verify
  Inputs (in this folder):
    Scope.csv           - FINAL list of in-scope addresses (column Address)
    Teardown-Rules.txt  - RuleIdentity values (from 02-Reply-Forward-Rules.csv) to DISABLE, one per line
    Teardown-OOF.csv    - columns Address, Action  (Action = Off | ExternalOff)
                            Off         -> out-of-office fully disabled (team boxes, old templates)
                            ExternalOff -> ExternalAudience None: colleagues still see it, externals get the central reply
  Run with -WhatIf first to preview every change:   .\04-GoLive.ps1 -WhatIf
  Then for real:                                     .\04-GoLive.ps1
  Order: backup -> teardown -> group -> rule -> verify. Between teardown and rule, the
  affected boxes send no reply for a minute or two.
#>
[CmdletBinding(SupportsShouldProcess)]
param()
. "$PSScriptRoot\00-Config.ps1"

$Scope     = Get-ScopeAddresses
$RulesFile = Join-Path $PSScriptRoot 'Teardown-Rules.txt'
$OofFile   = Join-Path $PSScriptRoot 'Teardown-OOF.csv'
$OldRules  = if (Test-Path $RulesFile) { @(Get-Content $RulesFile | Where-Object { $_.Trim() -and -not $_.Trim().StartsWith('#') }) } else { @() }
$OofPlan   = if (Test-Path $OofFile)   { @(Import-Csv $OofFile) } else { @() }

# ---------- 0. Backup ----------
$Backup = New-WorkFolder 'GoLive-Backup'
Get-TransportRule -Identity $RuleName | Export-Clixml (Join-Path $Backup 'TransportRule.xml')
Get-DistributionGroupMember -Identity $ScopeGroup -ResultSize Unlimited |
    Select-Object Name, PrimarySmtpAddress | Export-Csv (Join-Path $Backup 'ScopeGroupMembers.csv') -NoTypeInformation
foreach ($o in $OofPlan) {
    Get-MailboxAutoReplyConfiguration -Identity $o.Address | Export-Clixml (Join-Path $Backup "$($o.Address.Split('@')[0])-OOF.xml")
}
$OldRules | Set-Content (Join-Path $Backup 'Teardown-Rules.txt')
Write-Host "Backup: $Backup   <-- keep this path for 05-Rollback.ps1" -ForegroundColor Green

# ---------- 1. Teardown old replies ----------
foreach ($id in $OldRules) {
    if ($PSCmdlet.ShouldProcess($id, 'Disable inbox rule')) { Disable-InboxRule -Identity $id -Confirm:$false; "Disabled rule $id" }
}
foreach ($o in $OofPlan) {
    switch ($o.Action) {
        'Off'         { if ($PSCmdlet.ShouldProcess($o.Address, 'OOF -> Disabled'))            { Set-MailboxAutoReplyConfiguration -Identity $o.Address -AutoReplyState Disabled;  "OOF off: $($o.Address)" } }
        'ExternalOff' { if ($PSCmdlet.ShouldProcess($o.Address, 'OOF ExternalAudience -> None')) { Set-MailboxAutoReplyConfiguration -Identity $o.Address -ExternalAudience None;  "OOF external off: $($o.Address)" } }
        default       { Write-Warning "Unknown Action '$($o.Action)' for $($o.Address) - skipped" }
    }
}

# ---------- 2. Scope group ----------
$have = (Get-DistributionGroupMember -Identity $ScopeGroup -ResultSize Unlimited).PrimarySmtpAddress
foreach ($a in $Scope) {
    if ($have -notcontains $a -and $PSCmdlet.ShouldProcess($a, "Add to $ScopeGroup")) {
        Add-DistributionGroupMember -Identity $ScopeGroup -Member $a -BypassSecurityGroupManagerCheck; "Added $a"
    }
}

# ---------- 3. Mail flow rule (direct list = exactly Scope.csv) ----------
if ($PSCmdlet.ShouldProcess($RuleName, "SentTo = $($Scope.Count) addresses")) {
    Set-TransportRule -Identity $RuleName -SentTo $Scope
}

# ---------- 4. Verify ----------
Write-Host "`nVERIFY" -ForegroundColor Cyan
$OldRules | ForEach-Object { Get-InboxRule -Identity $_ | Select-Object MailboxOwnerId, Name, Enabled } | Format-Table -AutoSize
$OofPlan  | ForEach-Object { Get-MailboxAutoReplyConfiguration -Identity $_.Address | Select-Object Identity, AutoReplyState, ExternalAudience } | Format-Table -AutoSize
"Scope.csv addresses : $($Scope.Count)"
"Group members       : $((Get-DistributionGroupMember -Identity $ScopeGroup -ResultSize Unlimited).Count)"
"Rule SentTo         : $((Get-TransportRule -Identity $RuleName).SentTo.Count)"
Write-Host "Next: smoke test from an EXTERNAL address (normal subject, no 'auto reply' / 'out of office' words)." -ForegroundColor Yellow
