SharePoint external share expiry - setup toolkit
From the Ground Truth field note "Making 'Specific people' links expire, per person".

01-Get-SharingBaseline.ps1          read-only: tenant sharing settings + audit-log summary
02-New-AutomationServiceAccount.ps1 role-less service account, licence with only the plans you keep
03-Set-ShareExpirySite.ps1          site sharing settings + service account Owner and Site Collection Admin
04-New-AlertSenderMailbox.ps1       shared sender mailbox, Send As, forwarding
Email-Compose-Template.html         HTML for the flow's "Email HTML" Compose action

All scripts are interactive: run with no parameters and they prompt. 01 and 03 need
Windows PowerShell 5.1 (SharePoint Online cmdlets). Downloaded scripts are blocked by
Windows: Get-ChildItem *.ps1 | Unblock-File
Test in a non-production site first.
