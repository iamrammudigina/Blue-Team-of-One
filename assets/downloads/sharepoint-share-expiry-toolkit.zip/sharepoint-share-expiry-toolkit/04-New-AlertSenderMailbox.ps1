<#
.SYNOPSIS
    Create the shared mailbox the flow sends its daily report from, give the service
    account Send As, and forward the service account's own mail to a monitored address.

.DESCRIPTION
    Step 4 of the SharePoint External Share Expiry automation.
      - Shared mailbox (no licence) with a readable name, e.g. "Expert Access Alerts",
        hidden from the address book. Reports show that name instead of a service account.
      - Send As for the service account, so the flow's "Send an email (V2)" can use it in
        "From (Send as)". One service account can own many automations, each with its own sender.
      - Forwards the service account's mailbox (keeping a copy) to the alerts DL, because
        Power Automate sends flow-failure notices to the flow owners.
    Re-runnable: existing objects are reused.

.PARAMETER SenderAddress
    e.g. share-expiry-alerts@<domain>. Prompted if omitted.

.PARAMETER SenderName
    Display name, e.g. "Expert Access Alerts". Prompted if omitted.

.PARAMETER ServiceAccount
    The flow owner's UPN. Prompted if omitted.

.PARAMETER ForwardTo
    Where the service account's mail goes (the alerts DL). Empty = no forwarding.

.EXAMPLE
    .\04-New-AlertSenderMailbox.ps1

.NOTES
    Author : Ram Mudigina, Surya Technologies
    Needs  : ExchangeOnlineManagement; Exchange Administrator (or Recipient Management).
    Tested : New-Mailbox -Shared / Add-RecipientPermission / Set-Mailbox commands confirmed in production on
             2026-10-05. Packaged afterwards: first full run to confirm.
    Gotcha : Send As can take up to ~60 minutes to apply. Until then the flow's send fails with
             "not allowed to send on behalf of".
             The service account needs a working mailbox (Exchange plan provisioned) before forwarding.
#>

[CmdletBinding()]
param(
    [string]$SenderAddress,
    [string]$SenderName,
    [string]$ServiceAccount,
    [string]$ForwardTo
)

$ErrorActionPreference = 'Stop'

$exo = $true
try { Get-OrganizationConfig | Out-Null } catch { $exo = $false }
if (-not $exo) { Connect-ExchangeOnline -ShowBanner:$false }

if (-not $SenderAddress) {
    do { $SenderAddress = (Read-Host 'Sender shared mailbox address (e.g. share-expiry-alerts@<domain>)').Trim() }
    until ($SenderAddress -match '^[^@\s]+@[^@\s]+\.[^@\s]+$')
}
if (-not $SenderName)     { $SenderName = Read-Host 'Sender display name (e.g. Expert Access Alerts)' }
if (-not $ServiceAccount) { do { $ServiceAccount = (Read-Host 'Service account UPN').Trim() } until ($ServiceAccount -match '@') }
if ($null -eq $PSBoundParameters['ForwardTo']) {
    $ForwardTo = (Read-Host 'Forward the service account mail to (alerts DL; Enter = none)').Trim()
}

Write-Host "`nPlanned:" -ForegroundColor Yellow
Write-Host "  Shared mailbox '$SenderName' <$SenderAddress>, hidden from address lists"
Write-Host "  Send As for $ServiceAccount"
if ($ForwardTo) { Write-Host "  $ServiceAccount forwards to $ForwardTo (keeps a copy)" }
if ((Read-Host 'Type YES to apply') -ne 'YES') { return }

$mbx = Get-Mailbox -Identity $SenderAddress -ErrorAction SilentlyContinue
if (-not $mbx) {
    $alias = $SenderAddress.Split('@')[0]
    $mbx = New-Mailbox -Shared -Name $SenderName -DisplayName $SenderName -Alias $alias -PrimarySmtpAddress $SenderAddress
    Write-Host "Created $SenderAddress" -ForegroundColor Green
} else {
    Write-Host "$SenderAddress already exists ($($mbx.RecipientTypeDetails)); reusing it." -ForegroundColor Yellow
}

$has = Get-RecipientPermission -Identity $SenderAddress -Trustee $ServiceAccount -ErrorAction SilentlyContinue |
       Where-Object { $_.AccessRights -contains 'SendAs' }
if (-not $has) {
    Add-RecipientPermission -Identity $SenderAddress -Trustee $ServiceAccount -AccessRights SendAs -Confirm:$false | Out-Null
}
Set-Mailbox -Identity $SenderAddress -HiddenFromAddressListsEnabled $true

if ($ForwardTo) {
    Set-Mailbox -Identity $ServiceAccount -ForwardingSmtpAddress "smtp:$ForwardTo" -DeliverToMailboxAndForward $true
}

Write-Host "`n== Result" -ForegroundColor Cyan
Get-Mailbox $SenderAddress | Format-List DisplayName, PrimarySmtpAddress, RecipientTypeDetails, HiddenFromAddressListsEnabled
Get-RecipientPermission -Identity $SenderAddress | Where-Object Trustee -ne 'NT AUTHORITY\SELF' |
    Format-Table Trustee, AccessRights -AutoSize
Get-Mailbox $ServiceAccount | Format-List ForwardingSmtpAddress, DeliverToMailboxAndForward

Write-Host 'In the flow: Send an email (V2) -> Show all -> From (Send as) = the sender address.' -ForegroundColor Yellow
Write-Host 'If sending fails with "not allowed to send on behalf of", wait up to 60 minutes for Send As.' -ForegroundColor DarkGray
