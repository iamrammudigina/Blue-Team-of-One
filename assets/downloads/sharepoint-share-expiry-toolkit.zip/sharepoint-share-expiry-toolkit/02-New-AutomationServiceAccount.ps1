<#
.SYNOPSIS
    Create a dedicated, role-less service account to own Power Automate flows, licensed
    with only the plans the flows need (Exchange, SharePoint, Power Automate).

.DESCRIPTION
    Step 2 of the SharePoint External Share Expiry automation. Reusable for any client
    automation that needs a non-person owner, so flows keep running when people leave.
      1. Creates the user (no directory roles, password never expires, usage location set).
      2. Generates a 32-character password and shows it ONCE: put it in the team vault.
      3. Waits until the account is visible, then assigns a licence SKU you pick from a
         numbered list, with every service plan disabled except the ones you keep.

    After this script: sign in once as the account (register MFA, ideally an authenticator
    TOTP whose secret goes in the vault), then build the flow or Save As a copy under it.

.PARAMETER UserPrincipalName
    e.g. svc-powerautomate@<domain>. Prompted if omitted.

.PARAMETER UsageLocation
    Two-letter country code required for licensing. Default US.

.PARAMETER KeepPlans
    Service plan names to leave on. Default: Exchange Online, SharePoint Online, Power Automate.

.EXAMPLE
    .\02-New-AutomationServiceAccount.ps1

.NOTES
    Author : Ram Mudigina, Surya Technologies
    Needs  : Microsoft.Graph.Users, Microsoft.Graph.Identity.DirectoryManagement (v2+).
             Scopes User.ReadWrite.All, Organization.Read.All. User Administrator + License Administrator.
    Tested : New-MgUser / Set-MgUserLicense commands confirmed in production on 2026-10-05 (service account,
             E5 with EXCHANGE_S_ENTERPRISE, SHAREPOINTENTERPRISE, FLOW_O365_P3). Packaged afterwards:
             first full run to confirm.
    Gotcha : Licensing seconds after creation left the Exchange plan in "Error" (Exchange could not see
             the user yet). It self-healed, but this script waits 90 s before licensing.
             Some E5 background plans cannot be disabled; the script reports them and carries on.
             A password change later breaks every flow connection owned by the account.
#>

[CmdletBinding()]
param(
    [string]$UserPrincipalName,
    [string]$DisplayName,
    [string]$UsageLocation = 'US',
    [string[]]$KeepPlans = @('EXCHANGE_S_ENTERPRISE','SHAREPOINTENTERPRISE','FLOW_O365_P3')
)

$ErrorActionPreference = 'Stop'

if (-not (Get-MgContext)) {
    Connect-MgGraph -Scopes 'User.ReadWrite.All','Organization.Read.All' -NoWelcome
}

if (-not $UserPrincipalName) {
    do { $UserPrincipalName = (Read-Host 'Service account UPN (e.g. svc-powerautomate@<domain>)').Trim() }
    until ($UserPrincipalName -match '^[^@\s]+@[^@\s]+\.[^@\s]+$')
}
if (-not $DisplayName) { $DisplayName = $UserPrincipalName.Split('@')[0] }

$existing = Get-MgUser -Filter "userPrincipalName eq '$UserPrincipalName'" -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "Account already exists ($($existing.Id)). Skipping creation, going to licensing." -ForegroundColor Yellow
    $svc = $existing
} else {
    $chars = [char[]]'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*-_=+'
    $rng   = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $bytes = New-Object byte[] 32; $rng.GetBytes($bytes)
    $plain = -join ($bytes | ForEach-Object { $chars[$_ % $chars.Length] })

    Write-Host "`nAbout to create $UserPrincipalName ($DisplayName), usage location $UsageLocation, no roles." -ForegroundColor Cyan
    if ((Read-Host 'Type YES to create') -ne 'YES') { return }

    $svc = New-MgUser -DisplayName $DisplayName -UserPrincipalName $UserPrincipalName `
        -MailNickname $UserPrincipalName.Split('@')[0] -AccountEnabled -UsageLocation $UsageLocation `
        -PasswordPolicies 'DisablePasswordExpiration' `
        -PasswordProfile @{ Password = $plain; ForceChangePasswordNextSignIn = $false }

    Write-Host "`nCreated. Object ID: $($svc.Id)" -ForegroundColor Green
    Write-Host 'Password (shown once, store it in the vault now):' -ForegroundColor Yellow
    Write-Host $plain
    $plain = $null
    Read-Host 'Press Enter once the password is in the vault'

    Write-Host 'Waiting 90 seconds so Exchange can see the new user before licensing...'
    Start-Sleep -Seconds 90
}

# --- Licence ---------------------------------------------------------------------
$skus = @(Get-MgSubscribedSku | Where-Object { $_.CapabilityStatus -eq 'Enabled' } |
          Sort-Object SkuPartNumber)
Write-Host "`nAvailable licences:" -ForegroundColor Cyan
for ($i = 0; $i -lt $skus.Count; $i++) {
    $free = $skus[$i].PrepaidUnits.Enabled - $skus[$i].ConsumedUnits
    '{0,3}. {1,-40} free: {2}' -f ($i + 1), $skus[$i].SkuPartNumber, $free | Write-Host
}
do { $n = [int](Read-Host 'Pick the licence number') } until ($n -ge 1 -and $n -le $skus.Count)
$sku = $skus[$n - 1]
if (($sku.PrepaidUnits.Enabled - $sku.ConsumedUnits) -lt 1) { throw "No free $($sku.SkuPartNumber) seats." }

$missing = $KeepPlans | Where-Object { $_ -notin $sku.ServicePlans.ServicePlanName }
if ($missing) {
    Write-Warning "These plans are not in $($sku.SkuPartNumber): $($missing -join ', ')"
    Write-Host 'Plans in this SKU:'; $sku.ServicePlans.ServicePlanName | Sort-Object | ForEach-Object { "  $_" }
    $k = Read-Host 'Plan names to keep, comma-separated'
    $KeepPlans = @($k -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

$off = @($sku.ServicePlans | Where-Object { $_.ServicePlanName -notin $KeepPlans } |
         Select-Object -ExpandProperty ServicePlanId)
Set-MgUserLicense -UserId $svc.Id -AddLicenses @(@{ SkuId = $sku.SkuId; DisabledPlans = $off }) -RemoveLicenses @() | Out-Null

Start-Sleep -Seconds 10
$lic = Get-MgUserLicenseDetail -UserId $svc.Id | Where-Object SkuId -eq $sku.SkuId
Write-Host "`n== Plans now on $UserPrincipalName" -ForegroundColor Cyan
$lic.ServicePlans | Where-Object ProvisioningStatus -ne 'Disabled' |
    Sort-Object ServicePlanName | Format-Table ServicePlanName, ProvisioningStatus -AutoSize
Write-Host 'Background plans that stay on cannot be used as apps; that is expected.' -ForegroundColor DarkGray
Write-Host "If Exchange shows Error or PendingProvisioning, wait 15 minutes and re-check (Get-Mailbox $UserPrincipalName)." -ForegroundColor DarkGray

Write-Host "`nNext:" -ForegroundColor Yellow
Write-Host '  1. Sign in once as the account and register MFA (TOTP secret in the vault).'
Write-Host '  2. If your country-block CA policy blocks where you are, add the account to its exclude group for setup only, then remove it.'
Write-Host '  3. Run 03-Set-ShareExpirySite.ps1 and 04-New-AlertSenderMailbox.ps1.'
