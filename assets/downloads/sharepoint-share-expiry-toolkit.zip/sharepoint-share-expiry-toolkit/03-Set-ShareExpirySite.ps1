<#
.SYNOPSIS
    Configure the expert-sharing site and give the flow's service account the access it
    needs: Site Owner + Site Collection Admin on this one site only.

.DESCRIPTION
    Step 3 of the SharePoint External Share Expiry automation.
      - External sharing on the site: existing + new guests only (blocks Anyone links on
        this site without touching the tenant).
      - Default link: Specific people, with View or Edit (you choose).
      - Turns OFF the site's guest-expiry override, so it can't overlap the flow
        (guest expiry removes the guest from EVERY case on the site at once).
      - Adds the service account to the site Owners group and makes it Site Collection Admin.
    Shows the settings before and after, and asks before changing anything.

.PARAMETER SiteUrl
    https://<tenant>.sharepoint.com/sites/<SiteName>. Prompted if omitted.

.PARAMETER ServiceAccount
    The flow owner's UPN, e.g. svc-powerautomate@<domain>. Prompted if omitted.

.EXAMPLE
    .\03-Set-ShareExpirySite.ps1

.NOTES
    Author : Ram Mudigina, Surya Technologies
    Needs  : Microsoft.Online.SharePoint.PowerShell; SharePoint Administrator.
             Windows PowerShell 5.1 (SPO cmdlets are not recognised in PowerShell 7).
    Tested : Set-SPOSite / Add-SPOUser / Set-SPOUser commands confirmed in production on 2026-10-02 and
             2026-10-05. Packaged afterwards: first full run to confirm.
    Gotcha : Site Owner is NOT enough. Removing one person from a link means editing the hidden
             SharingLinks.<item>.Flexible.<link> group, and only a Site Collection Admin can.
             As Owner only, the flow's "Remove from link" step fails with 403 Access denied.
             The site's creator is Site Collection Admin automatically, which hides this in testing.
#>

[CmdletBinding()]
param(
    [string]$SiteUrl,
    [string]$ServiceAccount,
    [ValidateSet('View','Edit')][string]$DefaultLinkPermission
)

$ErrorActionPreference = 'Stop'

if ($PSVersionTable.PSEdition -eq 'Core') {
    Write-Warning 'Running in PowerShell 7. Open "Windows PowerShell" (5.1) and run again.'
    return
}

if (-not $SiteUrl) {
    do { $SiteUrl = (Read-Host 'Site URL (https://<tenant>.sharepoint.com/sites/<name>)').Trim().TrimEnd('/') }
    until ($SiteUrl -match '^https://[^.]+\.sharepoint\.com/(sites|teams)/[^/]+$')
}
if (-not $ServiceAccount) {
    do { $ServiceAccount = (Read-Host 'Service account UPN').Trim() } until ($ServiceAccount -match '@')
}
if (-not $DefaultLinkPermission) {
    do { $DefaultLinkPermission = (Read-Host 'Default link permission for shares: View or Edit').Trim() }
    until ($DefaultLinkPermission -in 'View','Edit')
}

$connected = $true
try { Get-SPOTenant | Out-Null } catch { $connected = $false }
if (-not $connected) {
    $admin = $SiteUrl -replace '^https://([^.]+)\.sharepoint\.com.*$','https://$1-admin.sharepoint.com'
    Connect-SPOService -Url $admin
}

function Show-Site {
    $s = Get-SPOSite -Identity $SiteUrl -Detailed
    [pscustomobject]@{
        Template                                    = $s.Template
        SharingCapability                           = $s.SharingCapability
        DefaultSharingLinkType                      = $s.DefaultSharingLinkType
        DefaultLinkPermission                       = $s.DefaultLinkPermission
        OverrideTenantExternalUserExpirationPolicy  = $s.OverrideTenantExternalUserExpirationPolicy
        ExternalUserExpirationInDays                = $s.ExternalUserExpirationInDays
    } | Format-List | Out-String | Write-Host
}

Write-Host "`n== Before" -ForegroundColor Cyan
Show-Site

$owners = @(Get-SPOSiteGroup -Site $SiteUrl | Where-Object { $_.Title -like '* Owners' })
if ($owners.Count -ne 1) {
    $all = @(Get-SPOSiteGroup -Site $SiteUrl)
    for ($i = 0; $i -lt $all.Count; $i++) { '{0,3}. {1}' -f ($i + 1), $all[$i].Title | Write-Host }
    do { $n = [int](Read-Host 'Pick the Owners group number') } until ($n -ge 1 -and $n -le $all.Count)
    $ownersGroup = $all[$n - 1].Title
} else { $ownersGroup = $owners[0].Title }

Write-Host "Planned changes on ${SiteUrl}:" -ForegroundColor Yellow
Write-Host '  SharingCapability                          -> ExternalUserSharingOnly (Anyone links blocked on this site)'
Write-Host "  DefaultSharingLinkType / Permission        -> Direct (Specific people) / $DefaultLinkPermission"
Write-Host '  OverrideTenantExternalUserExpirationPolicy -> False (no guest expiry on this site)'
Write-Host "  $ServiceAccount -> member of '$ownersGroup' + Site Collection Admin"
if ((Read-Host 'Type YES to apply') -ne 'YES') { return }

Set-SPOSite -Identity $SiteUrl -SharingCapability ExternalUserSharingOnly `
    -DefaultSharingLinkType Direct -DefaultLinkPermission $DefaultLinkPermission `
    -OverrideTenantExternalUserExpirationPolicy $false

Add-SPOUser -Site $SiteUrl -LoginName $ServiceAccount -Group $ownersGroup | Out-Null
Set-SPOUser -Site $SiteUrl -LoginName $ServiceAccount -IsSiteCollectionAdmin $true | Out-Null

Write-Host "`n== After" -ForegroundColor Cyan
Show-Site
$u = Get-SPOUser -Site $SiteUrl -LoginName $ServiceAccount
Write-Host ("{0}: IsSiteAdmin = {1}; Groups = {2}" -f $ServiceAccount, $u.IsSiteAdmin, ($u.Groups -join ', ')) -ForegroundColor Green
Write-Host "`nNext: create the 'Sharing Tracker' list (see docs/Build-Guide.md, part 3) and lock it to owners." -ForegroundColor Yellow
