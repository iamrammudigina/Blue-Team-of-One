<#
.SYNOPSIS
    Read-only: show how a tenant really shares files externally, before you design an
    expiry fix. Tenant sharing settings + a summary of sharing events from the audit log.

.DESCRIPTION
    Step 1 of the SharePoint External Share Expiry automation. Answers the questions that
    decided the design in the first deployment:
      - Which link types can the tenant expire at all? (Only Anyone links, and the newer
        People-in-org policy. There is no admin expiry for Specific people links.)
      - Do the users actually create Anyone links, or Specific people links?
      - Are people added to links that already exist? (Link reuse: one link date is not
        each person's share date.)
      - Has anyone set an expiry date by hand?
    Optionally limits the audit search to the people who do the sharing, and exports CSVs.

    Changes nothing.

.PARAMETER AdminUrl
    SharePoint admin URL, e.g. https://<tenant>-admin.sharepoint.com. Prompted if omitted.

.PARAMETER Users
    UPNs of the people who share (comma-separated). Empty = everyone.

.PARAMETER Days
    How far back to search the audit log. Default 90 (the audit log keeps 180 days on E5).

.EXAMPLE
    .\01-Get-SharingBaseline.ps1
    Fully interactive.

.NOTES
    Author : Ram Mudigina, Surya Technologies
    Needs  : Microsoft.Online.SharePoint.PowerShell (SharePoint Administrator) and
             ExchangeOnlineManagement (audit log search role, e.g. View-Only Audit Logs).
             Run in Windows PowerShell 5.1: the SPO cmdlets are not recognised in PowerShell 7.
    Tested : Get-SPOTenant settings and Search-UnifiedAuditLog -RecordType SharePointSharingOperation
             confirmed in production on 2026-10-02. Packaged into this script afterwards: first full run to confirm.
    Gotcha : Search-UnifiedAuditLog returns at most 5,000 rows per page and 50,000 per session.
             For bigger tenants shorten -Days or pass -Users.
#>

[CmdletBinding()]
param(
    [string]$AdminUrl,
    [string[]]$Users,
    [ValidateRange(1,180)][int]$Days = 90
)

$ErrorActionPreference = 'Stop'

if ($PSVersionTable.PSEdition -eq 'Core') {
    Write-Warning 'Running in PowerShell 7. The SharePoint Online cmdlets need Windows PowerShell 5.1. Open "Windows PowerShell" and run again.'
    return
}

# --- SharePoint Online --------------------------------------------------------
$connected = $true
try { Get-SPOTenant | Out-Null } catch { $connected = $false }
if (-not $connected) {
    if (-not $AdminUrl) {
        do { $AdminUrl = (Read-Host 'SharePoint admin URL (https://<tenant>-admin.sharepoint.com)').Trim().TrimEnd('/') }
        until ($AdminUrl -match '^https://[^.]+-admin\.sharepoint\.com$')
    }
    Connect-SPOService -Url $AdminUrl
}

$t = Get-SPOTenant
$settings = [ordered]@{
    SharingCapability                   = $t.SharingCapability
    RequireAnonymousLinksExpireInDays   = $t.RequireAnonymousLinksExpireInDays
    ExternalUserExpirationRequired      = $t.ExternalUserExpirationRequired
    ExternalUserExpireInDays            = $t.ExternalUserExpireInDays
    DefaultSharingLinkType              = $t.DefaultSharingLinkType
    DefaultLinkPermission               = $t.DefaultLinkPermission
    EnableAzureADB2BIntegration         = $t.EnableAzureADB2BIntegration
    SharingDomainRestrictionMode        = $t.SharingDomainRestrictionMode
}
Write-Host "`n== Tenant sharing settings" -ForegroundColor Cyan
$settings.GetEnumerator() | ForEach-Object { '{0,-36} {1}' -f $_.Key, $_.Value } | Write-Host

Write-Host "`nWhat this means:" -ForegroundColor Yellow
if ($t.RequireAnonymousLinksExpireInDays -gt 0) {
    Write-Host "  - Anyone links expire after $($t.RequireAnonymousLinksExpireInDays) days. This is the ONLY admin expiry for external links."
} else {
    Write-Host '  - Anyone links never expire (no admin limit set).'
}
Write-Host '  - Specific people links have no admin expiry setting. They expire only if the sharer types a date.'
if (-not $t.ExternalUserExpirationRequired) {
    Write-Host "  - Guest expiration is OFF tenant-wide (ExternalUserExpireInDays = $($t.ExternalUserExpireInDays) is ignored)."
}

# --- Audit log ------------------------------------------------------------------
if ($null -eq $Users) {
    $u = Read-Host 'UPNs of the people who share, comma-separated (Enter = everyone)'
    $Users = @($u -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

$exo = $true
try { Get-OrganizationConfig | Out-Null } catch { $exo = $false }
if (-not $exo) { Connect-ExchangeOnline -ShowBanner:$false }

$start = (Get-Date).AddDays(-$Days)
$end   = Get-Date
$sid   = [guid]::NewGuid().ToString()
$rows  = New-Object System.Collections.Generic.List[object]
Write-Host "`nSearching $Days days of sharing events (this can take a few minutes)..." -ForegroundColor Cyan
do {
    $p = @{ StartDate = $start; EndDate = $end; RecordType = 'SharePointSharingOperation'
            SessionId = $sid; SessionCommand = 'ReturnLargeSet'; ResultSize = 5000 }
    if ($Users.Count) { $p.UserIds = $Users }
    $page = @(Search-UnifiedAuditLog @p)
    $page | ForEach-Object { $rows.Add($_) }
    Write-Host "  $($rows.Count) events so far"
} while ($page.Count -eq 5000 -and $rows.Count -lt 50000)

if (-not $rows.Count) { Write-Host 'No sharing events found.' -ForegroundColor Yellow; return }

$parsed = foreach ($r in $rows) {
    $a = $r.AuditData | ConvertFrom-Json
    [pscustomobject]@{
        Date       = $r.CreationDate
        User       = $r.UserIds
        Operation  = $r.Operations
        Target     = $a.TargetUserOrGroupName
        TargetType = $a.TargetUserOrGroupType
        Item       = $a.ObjectId
        EventData  = $a.EventData
    }
}

Write-Host "`n== Sharing operations ($Days days)" -ForegroundColor Cyan
$parsed | Group-Object Operation | Sort-Object Count -Descending |
    Format-Table @{n='Operation';e={$_.Name}}, Count -AutoSize

$anon   = @($parsed | Where-Object Operation -eq 'AnonymousLinkCreated').Count
$secure = @($parsed | Where-Object Operation -eq 'SecureLinkCreated').Count
$added  = @($parsed | Where-Object Operation -eq 'AddedToSecureLink').Count
$expiry = @($parsed | Where-Object { $_.Operation -match 'LinkUpdated' -and $_.EventData -match 'Expir' }).Count

Write-Host 'Reading:' -ForegroundColor Yellow
Write-Host "  - Anyone links created          : $anon  $(if(-not $anon){'(the tenant Anyone-link expiry never applied to these users)'})"
Write-Host "  - Specific people links created : $secure"
Write-Host "  - People added to existing links: $added  $(if($added -gt $secure){'(link reuse is common: age each PERSON, not each link)'})"
Write-Host "  - Link updates setting expiry   : $expiry"

$tenant = (Get-OrganizationConfig).Name.Split('.')[0]
$stamp  = Get-Date -Format yyyyMMdd_HHmm
$out    = Join-Path $env:TEMP "${tenant}_SharingBaseline_$stamp.csv"
$parsed | Export-Csv $out -NoTypeInformation -Encoding UTF8
Write-Host "`nEvents exported: $out" -ForegroundColor Green
